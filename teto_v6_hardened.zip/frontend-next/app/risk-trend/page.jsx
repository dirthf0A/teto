"use client";

import { useCallback, useState } from "react";
import TokenBar from "../_components/TokenBar";
import { fetchJson } from "../_lib/api";

export default function RiskTrendPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [trend, setTrend] = useState([]);

  const loadData = useCallback(async (token) => {
    if (!token) return;
    setLoading(true);
    setError("");
    try {
      const data = await fetchJson("/dashboard/risk-trend", token);
      setTrend(data?.days || []);
    } catch (err) {
      setError(err.message || "Failed to load risk trend");
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <>
      <section className="hero">
        <h1>Risk Trend</h1>
        <p>Visualize average risk score movement over the last 14 days.</p>
        <TokenBar onLoad={loadData} loading={loading} />
        {error ? <p className="empty">{error}</p> : null}
      </section>

      <section className="panel">
        {trend.length === 0 ? (
          <div className="empty">No risk trend data yet.</div>
        ) : (
          <div className="trend">
            {trend.map((day) => (
              <div className="trend-row" key={day.date}>
                <span>{day.date}</span>
                <div className="trend-bar">
                  <div
                    className="trend-fill"
                    style={{ width: `${Math.min(100, day.avg_risk)}%` }}
                  />
                </div>
                <strong>{day.avg_risk.toFixed(1)}</strong>
              </div>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
