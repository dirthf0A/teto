"use client";

import { useCallback, useState } from "react";
import TokenBar from "./_components/TokenBar";
import { fetchJson } from "./_lib/api";

export default function AttackSurfacePage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [surface, setSurface] = useState(null);
  const [overview, setOverview] = useState(null);

  const loadData = useCallback(async (token) => {
    if (!token) return;
    setLoading(true);
    setError("");
    try {
      const [surfaceData, overviewData] = await Promise.all([
        fetchJson("/dashboard/attack-surface", token),
        fetchJson("/dashboard/overview", token)
      ]);
      setSurface(surfaceData);
      setOverview(overviewData);
    } catch (err) {
      setError(err.message || "Failed to load attack surface data");
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <>
      <section className="hero">
        <h1>Attack Surface</h1>
        <p>
          Track total domains, services, endpoints, and exposure posture across
          your organization.
        </p>
        <TokenBar onLoad={loadData} loading={loading} />
        {error ? <p className="empty">{error}</p> : null}
      </section>

      <section className="grid">
        <div className="panel">
          <h3>Domains</h3>
          <div className="value">{surface ? surface.domains : "--"}</div>
        </div>
        <div className="panel">
          <h3>Subdomains</h3>
          <div className="value">{surface ? surface.subdomains : "--"}</div>
        </div>
        <div className="panel">
          <h3>Services</h3>
          <div className="value">{surface ? surface.services : "--"}</div>
        </div>
        <div className="panel">
          <h3>Endpoints</h3>
          <div className="value">{surface ? surface.endpoints : "--"}</div>
        </div>
        <div className="panel">
          <h3>IPs</h3>
          <div className="value">{surface ? surface.ips : "--"}</div>
        </div>
        <div className="panel">
          <h3>Open Alerts</h3>
          <div className="value">{overview ? overview.open_alerts : "--"}</div>
        </div>
      </section>

      <section className="panel">
        <h3>Latest Scan</h3>
        <div className="value" style={{ fontSize: "1.4rem" }}>
          {overview?.latest_scan_completed_at || "No scans completed yet"}
        </div>
      </section>
    </>
  );
}
