"use client";

import { useCallback, useState } from "react";
import TokenBar from "../_components/TokenBar";
import { fetchJson } from "../_lib/api";

export default function VulnerabilitiesPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [findings, setFindings] = useState([]);

  const loadData = useCallback(async (token) => {
    if (!token) return;
    setLoading(true);
    setError("");
    try {
      const data = await fetchJson("/vulnerabilities", token);
      setFindings(data || []);
    } catch (err) {
      setError(err.message || "Failed to load vulnerabilities");
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <>
      <section className="hero">
        <h1>Vulnerability List</h1>
        <p>Prioritize critical findings and track remediation status.</p>
        <TokenBar onLoad={loadData} loading={loading} />
        {error ? <p className="empty">{error}</p> : null}
      </section>

      <section className="panel">
        {findings.length === 0 ? (
          <div className="empty">No findings yet.</div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Severity</th>
                <th>Title</th>
                <th>Target</th>
                <th>Risk</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {findings.slice(0, 25).map((finding) => (
                <tr key={finding.id}>
                  <td>
                    <span className={`badge severity-${finding.severity}`}>
                      {finding.severity}
                    </span>
                  </td>
                  <td>{finding.title}</td>
                  <td>{finding.target || "--"}</td>
                  <td>{finding.risk_score ?? "--"}</td>
                  <td>{finding.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}
