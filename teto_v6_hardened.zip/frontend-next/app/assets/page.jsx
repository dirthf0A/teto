"use client";

import { useCallback, useState } from "react";
import TokenBar from "../_components/TokenBar";
import { fetchJson } from "../_lib/api";

export default function AssetInventoryPage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [assets, setAssets] = useState([]);

  const loadData = useCallback(async (token) => {
    if (!token) return;
    setLoading(true);
    setError("");
    try {
      const data = await fetchJson("/assets", token);
      setAssets(data || []);
    } catch (err) {
      setError(err.message || "Failed to load assets");
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <>
      <section className="hero">
        <h1>Asset Inventory</h1>
        <p>Centralized view of hosts, services, and exposure classification.</p>
        <TokenBar onLoad={loadData} loading={loading} />
        {error ? <p className="empty">{error}</p> : null}
      </section>

      <section className="panel">
        {assets.length === 0 ? (
          <div className="empty">No assets yet.</div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Host</th>
                <th>IP</th>
                <th>Port</th>
                <th>Service</th>
                <th>Exposure</th>
                <th>Risk</th>
              </tr>
            </thead>
            <tbody>
              {assets.slice(0, 20).map((asset) => (
                <tr key={asset.id}>
                  <td>
                    {asset.url ||
                      asset.subdomain ||
                      asset.domain ||
                      asset.ip ||
                      `asset-${asset.id}`}
                  </td>
                  <td>{asset.ip || "--"}</td>
                  <td>
                    {asset.port ? `${asset.port}/${asset.protocol || "tcp"}` : "--"}
                  </td>
                  <td>{asset.service || asset.asset_type || "--"}</td>
                  <td>
                    {asset.exposure_classification ||
                      asset.exposure_class ||
                      "--"}
                  </td>
                  <td>{asset.risk_score ?? "--"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}
