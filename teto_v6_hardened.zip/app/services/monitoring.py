from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.models import Scan
from app.services.queue import get_queue


def create_scheduled_scan(db: Session, org_id: int, scan_type: str) -> Scan:
    scan = Scan(
        org_id=org_id,
        asset_id=None,
        scan_type=scan_type,
        status="scheduled",
        scheduled_at=datetime.utcnow(),
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)
    try:
        queue = get_queue()
    except Exception:  # noqa: BLE001
        queue = None
    if queue:
        queue.enqueue(scan.id)
    return scan


def should_run_deep_scan(now: datetime) -> bool:
    # Monthly on day 1.
    return now.day == 1


def next_daily_run(now: datetime) -> datetime:
    return now + timedelta(days=1)
