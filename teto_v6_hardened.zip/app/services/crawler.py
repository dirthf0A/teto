from __future__ import annotations

from typing import Iterable, List
from urllib.parse import urlparse

from app import config
from app.services import scanning


HIGH_VALUE_PATHS = ("/admin", "/api", "/debug", "/graphql")


def crawl_urls(targets: Iterable[str]) -> List[str]:
    return scanning.run_katana(targets)


def crawl_domain(domain: str) -> List[str]:
    if not domain:
        return []
    if domain.startswith("http://") or domain.startswith("https://"):
        targets = [domain]
    else:
        targets = [f"https://{domain}", f"http://{domain}"]
    return crawl_urls(targets)


def extract_high_value_endpoints(urls: Iterable[str]) -> List[str]:
    results: List[str] = []
    seen = set()
    limit = config.get_endpoint_limit()
    for url in urls:
        if not url:
            continue
        path = urlparse(url).path.lower()
        if not any(token in path for token in HIGH_VALUE_PATHS):
            continue
        if url in seen:
            continue
        seen.add(url)
        results.append(url)
        if len(results) >= limit:
            break
    return results
