from app.logger import get_logger
logger = get_logger("app.tasks.scheduler")
from datetime import datetime

from apscheduler.schedulers.blocking import BlockingScheduler
from sqlalchemy import select

from app import config
from app.db import SessionLocal, init_db
from app.models import Organization
from app.services.monitoring import create_scheduled_scan


def enqueue_scan_for_all_orgs(scan_type: str) -> None:
    db = SessionLocal()
    try:
        org_ids = db.execute(select(Organization.id)).scalars().all()
        for org_id in org_ids:
            create_scheduled_scan(db, org_id, scan_type)
    finally:
        db.close()


def run_scheduler() -> None:
    init_db()
    scheduler = BlockingScheduler()

    scheduler.add_job(
        lambda: enqueue_scan_for_all_orgs("asset_discovery"),
        "interval",
        hours=config.get_asset_scan_interval_hours(),
    )
    scheduler.add_job(
        lambda: enqueue_scan_for_all_orgs("vuln"),
        "interval",
        days=config.get_vuln_scan_interval_days(),
    )
    scheduler.add_job(
        lambda: enqueue_scan_for_all_orgs("deep"),
        "interval",
        days=config.get_deep_scan_interval_days(),
    )

    # Alert escalation check (every hour)
    def run_escalations():
        db = SessionLocal()
        try:
            from app.services.alert_engine import check_escalations
            count = check_escalations(db)
            if count:
                logger.info("escalated unacknowledged alerts", count=count)
        except Exception as e:
            logger.error("escalation check failed", error=str(e), exc_info=True)
        finally:
            db.close()

    scheduler.add_job(run_escalations, "interval", hours=1)

    logger.info("scheduler started", ts=datetime.utcnow().isoformat() + "Z")
    scheduler.start()


if __name__ == "__main__":
    run_scheduler()
